package ru.catssoftware.fakes.model;

public class PhantomLevelFarmParams {
}
