package ru.catssoftware.fakes.objects;

public class PhantomBuff {
   public int id;
   public int level;

   public PhantomBuff(int id, int lvl) {
      this.id = id;
      this.level = lvl;
   }
}
