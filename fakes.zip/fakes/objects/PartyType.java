package ru.catssoftware.fakes.objects;

public enum PartyType {
   mage,
   limit,
   archer,
   dagger,
   warrior,
   stop,
   suspended;
}
